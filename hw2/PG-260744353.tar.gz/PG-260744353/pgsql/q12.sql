SELECT
	COUNT(DISTINCT S.sid) AS numstudents
FROM
	student S
;
