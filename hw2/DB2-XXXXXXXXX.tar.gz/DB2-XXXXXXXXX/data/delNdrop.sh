db2 -t -v <<-END 2>&1 | tee delNdrop.log
CONNECT TO cs421;

DROP TABLE student;
DROP TABLE enroll;
DROP TABLE courseoffer;
DROP TABLE course;

QUIT;
END
